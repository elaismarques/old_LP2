﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tipos_de_triangulo
{
    public partial class Form1 : Form
    {
        double primeiro_valor, segundo_valor, terceiro_valor;

        private void txtValorUm_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorUm.Text, out primeiro_valor))
            {
                MessageBox.Show("Insira um valor númerico!");
                txtValorUm.Text = "";
                txtValorUm.Focus();
            }
            if (primeiro_valor <= 0)
            {
                MessageBox.Show("O valor deve ser maior que zero!");
                txtValorUm.Clear();
            }
        }

        private void txtValorDois_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorDois.Text, out segundo_valor))
            {
                MessageBox.Show("Insira um valor númerico!");
                txtValorDois.Text = "";
                txtValorDois.Focus();
            }
            if ( segundo_valor <= 0)
            {
                MessageBox.Show("O valor deve ser maior do que zero!");
                txtValorDois.Clear();
            }

        }

        private void txtValorTres_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorTres.Text, out terceiro_valor))
            {
                MessageBox.Show("Insira um valor númerico!");
                txtValorTres.Text = "";
                txtValorTres.Focus();
            }
            if (terceiro_valor <=0)
            {
                MessageBox.Show("O valor dever ser maior do que zero");
                txtValorTres.Clear();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorUm.Clear();
            txtValorDois.Clear();
            txtValorTres.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (primeiro_valor == segundo_valor && primeiro_valor == terceiro_valor)
            {
                MessageBox.Show("É equilatero");
            }
            else if (primeiro_valor == segundo_valor || primeiro_valor == terceiro_valor || terceiro_valor == segundo_valor)
            {
                MessageBox.Show("É Isosceles");
            }
            else if ( primeiro_valor != segundo_valor || segundo_valor != terceiro_valor || terceiro_valor != primeiro_valor)
            {
                MessageBox.Show("É Escaleno");
            }
           
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
