﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calcular_IMC
{
    public partial class Form1 : Form
    {
        double peso, altura;
        string Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtResultado.Clear();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Valor Inválido!");
                txtPeso.Text = "";
                txtPeso.Focus();
            }
            else if (peso <= 0)
            {
                MessageBox.Show("O valor deve ser maior do que ZERO!");
                txtPeso.Clear();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Valor Inválido!");
                txtAltura.Text = "";
                txtAltura.Focus();
            }
            else if (altura <= 0)
            {
                MessageBox.Show("A altura deve ser maior do que ZERO");
                txtAltura.Clear();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //btnCalcular.BackColor = Color.SkyBlue;
            {
                double valorIMC;
                valorIMC = peso / (Math.Pow(altura, 2));
                Math.Round(valorIMC);
                txtResultado.Text = valorIMC.ToString();
              
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
