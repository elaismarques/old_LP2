﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        decimal numero1 = 0, numero2 = 0;
        string operacao;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "0";
        }

        private void btnUm_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "1";
        }

        private void btnDois_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "2";
        }

        private void btnTres_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "3";
        }

        private void btnQuatro_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "4";
        }

        private void btnCinco_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "5";
        }

        private void btnSeis_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "6";
        }

        private void btnSete_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "7";
        }

        private void btnOito_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "8";
        }

        private void btnNove_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + "9";
        }

        private void btnPonto_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text + ".";
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            numero1 = decimal.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "soma";
            lblOperacao.Text = "+";

        }
        private void btnSubtrai_Click(object sender, EventArgs e)
        {
            numero1 = decimal.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "subtrai";
            lblOperacao.Text = "-";
        }

        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            numero1 = decimal.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "multiplica";
            lblOperacao.Text = "X";
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            numero1 = decimal.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "dividir";
            lblOperacao.Text = "/";
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";
        }

        private void btnOFF_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            numero2 = decimal.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            if (operacao == "soma")
            {
                txtResultado.Text = Convert.ToString(numero1 + numero2);
            }
            else if (operacao == "subtrai")
            {
                txtResultado.Text = Convert.ToString(numero1 - numero2);
            }
            else if (operacao == "multiplica")
            {
                txtResultado.Text = Convert.ToString(numero1 * numero2);
            }
            else if (operacao == "dividir")
            {
                txtResultado.Text = Convert.ToString(numero1 / numero2);
            }

        }
    }
}
