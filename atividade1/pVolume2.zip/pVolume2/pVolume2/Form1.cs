﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pVolume2
{
    public partial class Form1 : Form
    {
        double raio;
        double altura;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Valor do raio inválido");
                txtRaio.Text = "";
                txtRaio.Focus();
            }
            else
            if (raio <= 0)
            {
                MessageBox.Show("O raio deve ser MAIOR que zero!");
            }
        }
        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Valor do raio inválido");
                txtAltura.Text = "";
                txtAltura.Focus();

                if (!double.TryParse(txtAltura.Text, out altura))
                {
                    MessageBox.Show("Valor da altura inválido");
                    txtAltura.Text = "";
                    txtAltura.Focus();
                }
            }
        }



        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //if (double.TryParse(txtAltura.Text, out altura))
            //if (double.TryParse(txtRaio.Text, out raio))
            {
                double volume;

                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Clear();
            txtVolume.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!((e.KeyChar >= (char)48 && (e.KeyChar <= (char)57))))
            {
                e.KeyChar = '\0';
            }

        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!((e.KeyChar >= (char)48 && (e.KeyChar <= (char)57))))
            {
                e.KeyChar = '\0';
            }
        }
    }
}
